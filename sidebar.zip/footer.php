<style>
/*  SECTIONS  */
.section {
	clear: both;
	padding: 0px;
	margin: 0px;
}

/*  COLUMN SETUP  */
.col {
	display: block;
	float:left;
	margin: 1% 0 1% 1.6%;
}
.col:first-child { margin-left: 0; }

/*  GROUPING  */
.group:before,
.group:after { content:""; display:table; }
.group:after { clear:both;}
.group { zoom:1; /* For IE 6/7 */ }

/*  GRID OF TWO  */
.span_2_of_2 {
	width: 100%;
}
.span_1_of_2 {
	width: 49.2%;
}

a {
	text-decoration: none;
	color: #000;
	
	}

/*  GO FULL WIDTH AT LESS THAN 480 PIXELS */

@media only screen and (max-width: 480px) {
	.col { 
		margin: 1% 0 1% 0%;
	}
}

@media only screen and (max-width: 480px) {
	.span_2_of_2, .span_1_of_2 { width: 100%; }
}

</style>
<body>
<div class="section group">
	<div class="col span_1_of_2">
	<h4>About 3wc</h4>
    <p>3Way communications Limited also known as 3WC, is a Nigerian registered firm specialized in direct marketing, software solutions and content service provision, we are involved in telecom value-added services (VAS) and new media provider, offering an array of next-generation mobile solutions based on innovative technologies and service platforms.</p>
    <p><a href='sms.php' class='button'>Read More</a></p>
    </div>
	<div class="col span_1_of_2">
		<h4>Contact 3wc</h4>
    <p>Feel free to leave a message for us with your contact information; you can ask any questions you might have about our products or services. Also, if you have a project in mind, please describe your requirements so that we can brainstorm on how to accomplish what you need.</p>
    <p><a href='about_us.php' class='button'>Read More</a></p>
  </div>
</div>
<div>
<h4 style="text-align:center">Selected Top Clients</h4>
<marquee behavior="alternate">
<img src="images/mtn.jpg">
<img src="images/glo.jpg">
<img src="images/airtel.jpg">
<img src="images/skye-bank.jpg">
<img src="images/stanbic-ibtc.jpg">
<img src="images/comviva.jpg">
<img src="images/timwe.jpg">
<img src="images/huawei.jpg">
<img src="images/nokia.jpg">
</marquee>
</div>
<div style="text-align:center">
  <p><i>Copyright 2016 | 3way Communications | Powered by 3WC | <a href="terms.php">Terms and Conditions</a> | <a href="privacy-policy.php">Privacy Policy</a></i></p>
</div>
</body>
