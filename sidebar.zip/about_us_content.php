<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/service-contents.css">
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div><img src="images/about-us-banna.jpg" width="100%" height="auto" alt="callertunes"></div>
<div class="section group">
	<div class="col main-article" style="border: solid 1px #c3c3c3; padding:1%">
	<h1>About Us</h1>
<p>3Way communications Limited also known as 3WC, is a Nigerian registered firm specialized in direct marketing, software solutions and content service provision, we are involved in telecom value-added services (VAS) and new media provider, offering an array of next-generation mobile solutions based on innovative technologies and service platforms.</p>

<p>Fully started operations in 2007 with SMS2TV services
Employs over 20 professionals.
3WC Patners with the following companies: MTN, ZAIN, GLO, ETISALAT, Nokia corporation – Finland, Tecno Telecom Limited & Dandon handsets – China. Content Providers; 
Woo interactive-Nigeria, SingmyRing-UK, Inner-active media-Israel, Inlogic software-solvak Republic, Boa-Bingtones Ltd, Ireland, BAMBOO in Austania and Huawei Nigeria.
</p>


<h3>MISSION</h3>
<p>To deliver entertainment, information, advertising & financial services to our customers through their mobile and non-mobile devices as the principal value-added service provider delivering relevant, need-filling solutions and adding value with quantifiable results.</p>


<h3>OUR KNOWLEDGE AND SKILLS</h3>
<p>3WC has expertise in providing variety of services and solutions in web development(PHP, ASP.NET, XML, Flash/Flex, Web 2.0) and Mobile App creation. In addition: We know the consumer, what they want and where to find them, We know how to develop tools and friendly interfaces through which customers can connect with services. and we also know the other players, and what their strengths and weaknesses are – Above all, we know how to best to serve our customers.</p>


<h3>CORE VALUES</h3>
<ul>
<li>Truth</li>
<li>All for one & one for all</li>
<li>Do not leave till work is done</li>
<li>Problem solvers.</li>
<li>Impossible is just a word (Result Oriented)</li>
<li>Information is never too much</li>
<li>We will deliver more than we promised, on time</li>
</ul>


<h3>MANAGEMENT PHILOSOPHY</h3>

<ul>
<li>Maximum creative freedom</li>
<li>Culture of openness</li>
<li>Empowerment through knowledge and mutual respect</li>
<li>Lateral structure</li>
<li>Technology-driven work environment</li>
<li>Performance-determined</li>
<li>We will deliver more than we promised on time</li>
</ul>

<h3>SOME OF OUR PRODUCTS AND SERVICES</h3>

<ul>
<li>Operator portals: For selling mobile content; Health and Education Content on Ovi(Nokia) life tools, MTNPlay, Glo 3G/WAP portal.</li>
<li>Callertunes: Make calls more enjoyable.</li>
<li>Shortcodes: Driven mobile content such as ringtones, logos, pictures, games e.t.c</li>
<li>GEEVEE: A new application which allows different smart phones to message and each other.</li>
<li>BLAAST: Many apps in one for unlimited Facebook, Twitter, Messenger, Wikipedia, News, Social Games, and more in one FREE download.</li>
<li>Dailyapps: Java applet for dispensing mobile content.  </li>
<li>Loaded SMS: A web portal for bulk SMS sales and mobile marketing. </li>
<li>VASPLUS: A web portal for managing multi-operator shortcode services.</li>
<li>SMS to TV Services: SMS to TV & Radiointeractive 2way SMS for media/TV houses.</li>
<li>Internet Marketing: Services for Blue-chips e.g. MTN, Etisalat, Airtel, Nigerian Breweries, Coca-Cola etc.</li>
<li>KAPSA: A multi-channel marketing platform that serves as an effective way to reach consumers anywhere.</li>
</ul>       

<div></div>

<div></div>
	</div>
	<div class="col main-sidebar"  style="border: solid 1px #c3c3c3;">
	<?php include 'sidebar.php'?>
</div>
</div>
  </div>
  </div>
  </body>