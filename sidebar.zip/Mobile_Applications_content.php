<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/service-contents.css">
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div><img src="images/mobile-app-banna.jpg" width="100%" height="auto" alt="callertunes"></div>
<div class="section group">
	<div class="col main-article" style="border: solid 1px #c3c3c3; padding:1%">
    <h1>Mobile Application</h1>
<p>A mobile application, most commonly referred to as an app, is a type of application software designed to run on a mobile device, such as a smartphone or tablet computer. Mobile applications frequently serve to provide users with similar services to those accessed on PCs. Apps are generally small, individual software units with limited function. This use of software has been popularized by Apple Inc. and its App Store, which sells thousands of applications for the iPhone, iPad and iPod Touch. Below are some of the applications 3wc manages:</p>

<h3>Afro Tunes</h3>
<p>Afrotunes is a Music streaming and download platform, optimized for android mobile devices which is socially enabled to accommodate cross-user activity.
It brings you free, unlimited access to all your favourite songs of Nollywood and African music, no matter wherever you are. Every mood select your favourite songs and artists, create your own personalized playlists which delivers your favourite music. 
Afrotunes was developed has been developed by a team of music lovers and below are it key features:</p>

<ul>
<li>Experience and form a Mobile Music lifestyle.</li>
<li>Stream songs with low data.</li>
<li>Download ringtones and callertunes</li>
<li>Navigate from one song/song category to the other.</li>
<li>Enjoy premium subscription and gift subscription.</li>
<li>Sharing musics on social medias.</li>
<li>Gift songs to family and friends</li>
<li>Play any song, on demand.</li>
<li>Create your own and save playlists unlimited.</li>
<li>Endless music for any mood, song, or artist.</li>
<li>Listening to music offline on the app after download.</li>
</ul>
 
<p>Powerful equalizer, Quick search all music and audio files, Easy to support all music & audio file formats, Online Music search, Custom background skin.
One of the most gorgeous and powerful music player for Android! You can manage your musics easily, Music Player will guide you easily to find all the music in your phone. This music player is not only based on artists or albums, but also based on the folder structure. The unique equalizer make your music sounds like you’ve never had before.</p>



<h3>GEEVEE</h3>
<p>3WC is involved in the promotion and distribution of GeeVee in Nigeria. The ALL-IN-ONE innovative communications application
With GeeVee you can Message and Call anyone in your GeeVee network for free! And call anyone else with or without an internet connection at the lowest rates directly from your smart phone. 
GeeVee was built by telecommunications experts for communications experts like you. GeeVee lets you call, text message, and play games on iPhone or Android for free. We know ALL the calling ins and outs, tricks and closely-guarded insider ways to give you:
Crystal clear call quality
Calling to anywhere in the world for free, or at the lowest rates possible to friends, family and contacts not using GeeVee
convenient ways to call. Forget about no Wi-Fi signals, expensive long distance calling rates, or inflated roaming charges stopping you from doing what you want.
Sharing of pictures, videos, voice recordings, messages, contacts, and other types of files with your contacts worldwide for free.</p>
	<div>
</div>

<div></div>
	</div>
	<div class="col main-sidebar"  style="border: solid 1px #c3c3c3;">
	<?php include 'sidebar.php'?>
</div>
</div>
  </div>
  </div>
  </body>