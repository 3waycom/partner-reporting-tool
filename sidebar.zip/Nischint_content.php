<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/service-contents.css">
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div><img src="images/Nischint.jpg" width="100%" height="auto" alt="callertunes"></div>
<div class="section group">
	<div class="col main-article" style="border: solid 1px #c3c3c3; padding:1%">
	<h1>Nischint</h1>
    <p>Nischint is the most advanced parental guidance and a unique software application service designed to support parents in their quest to provide the best level of information on digital media across all devices. With Nischint one can view phone calls and SMS made/received on childs device on real time. It furthers allow the following: </p>
    <p>&nbsp;</p>
    <div style="text-align:center">
    <iframe width="80%" height="255" src="https://www.youtube.com/embed/gK6schBSINg" frameborder="0" allowfullscreen></iframe>
    </div>
    <p>&nbsp;</p>
    <ol>
      <li>        It allows to view the images and videos taken on child device in real time.</li>
      <li>Whether it be a game or utility application, parents can view all the applications downloaded on child’s device.</li>
      <li>It also helps in locating child at any point with the help of interactive map showing the GPS track for the last 24 hours thus showing real time presence of kids location.</li>
      <li>It also helps to set up your child’s safe zone and receive real time alerts when the safe zone is crossed.</li>
      <li>Kids spend so much time on social networks like Facebook that it’s essential to monitor online social activity.</li>
      <li>Nischint helps you keep kids safer by showing who they are friends with and what type of content is being shared.</li>
      <li>On content level; one can proactively set the right filters for kids when connected online. This help parents to choose particular category of websites best suited to your child’s interest and security.</li>
      <li>Parents may access essential information from anywhere in the world. </li>
      </ol>
    <div>
	<h3 style="text-align: center;">KEY FEATURES</h3>
<h4>Monitor – Calls, SMS , Images, Videos, Apps and Websites</h4>
<p>With Nischint Monitoring feature you can now monitor :Phone Calls – Outgoing , incoming and missed calls, SMS – Sent and Received, Images, Videos Applications used and Websites visited. </p>

<h4>Schedule Application Usage</h4>
<p>Smartphones and tablets are becoming more and more like computers. Now customise mobile devices by installing software - known as mobile applications, or "apps".
</p>

<h4>Device Management</h4>
<p>Usage of child devices can be very tricky and if you feel that your child device has been compromised stolen or lost. This feature enables you to completely lock the child device remotely. </p>

<h4>Geo Track and Geo Safe Zone</h4>
<p>With Nischint Geo track and Safe zone you not only get to know where your child is but can also set up to 3 safe-zones. Rest assured we let you when you kid enters and exits a safe zone </p>

<h4>Website Filter</h4>
<p>With a database of more than 3.7Mn URLs you can be rest assured that objectionable content can be easily blocked using Nischints website filter features. Whats more, we know there are a zillion websites that we are unable to track thereby allowing you to create your own list of blocked websites </p>

<h4>Social Media Monitoring</h4>
<p>Gone are the days where our children would socialize on football field or over a board game at home. We live in an age of online and off world. Nischint gives the parents an option to connect to their child's Facebook account. </p>

    </div>
    <div>
      <h3 style="text-align: center;">INSTALLING NISCHINT</h3>
      <p>      New users can install the Nischint app on up to five family members’ devices, and then monitor and manage remotely from any internet-enabled device. You’re not limited to just Android devices either. Nischint works on Windows, and iOS as wel .</p>
      <p>How to Install and get started with Nischint?<br>
        Installing Nischint is simple in 2 easy steps<br>
      Step 1: Register as a parent and create an account. You can do the same via www.nischint.net or via our app. You may choose to go for the basic free version of the applictaion (limited features) or choos and advanced version.</p>
      <p>Step 2: Install on Child device. input your registered email id and password. you will be sent a pass code on your mobile no. (for Indian customers only) and email id. Input this passcode to verify your account and complete set up</p>
      <p>You are all set up and good to go!</p>
      <p>Important notes for users:<br>
        - Nischint for Android can protect the settings screen of your Child Android device. If this setting is activated, it will require you to type your Nischint passcode to access the settings screen on Android.</p>
      <p>If you have any feedback, questions, or concerns, please contact us at: 09030000108</p>
      <h4>&nbsp;</h4>
    </div>
    <p>&nbsp;</p>
    <div></div>

<div></div>
	</div>
	<div class="col main-sidebar"  style="border: solid 1px #c3c3c3;">
	<?php include 'sidebar.php'?>
	</div>
</div>
  </div>
  </div>
  </body>