<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/service-contents.css">
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div><img src="images/awashopper-bana.jpg" width="100%" height="auto" alt="callertunes"></div>
<div class="section group">
	<div class="col main-article" style="border: solid 1px #c3c3c3; padding:1%">
<h1>Full Tracks</h1>

<p>At 3WC, we use innovation to empower people, business and society. We are leaders in the indigenous feature phone manufacturing industry.  We envisage a networked society that is sustainable, where everything that can benefit from a connection will have, as we make our phones customized to fit your specific industry and business needs. Our partnerships with mobile and fixed networks give us immense capabilities to embed digital and multimedia services unto phones, to meet and exceed the needs of the clients and customers. Our understanding of the Nigerian and the wider African market has given us a name in the mobile phone industry. We provide very affordable phones with services that are relevant to the needs of the market, making a real difference to people’s lives and the world we live in today.</p>


<h3>The super-charged phone</h3>
<p>Fill it up, go all day. SeiTi W200 gives you up to 12 hours of talk time which you can leave on standby for up to 48 hours. With all that juice in the tank, it keeps going as long as you do. Make a statement with the SeiTi W200’s colour screen and bold body, available in black, red+black and white+red. Its bright, simple looks are complemented by a durable, dust and splash-proof keypad that keeps your phone working well.</p>

<p>It’s the little essentials that make life easier. Like multi-language support, t-flash card support, mp3, MPEG 4, Dual sim card dual standby, Digital camera, Bluetooth, 2.4” QVGA, Twin flashlight so you’re never in the dark and Fm Radio. The SeiTi Mobile comes preloaded with lots of multimedia contents includes: Callertunes, true-tones, full-tracks and wallpaper download. So for a little amount, you can get these mobile contents downloaded on your phone.</p>

<h3>The Multiple colored Phone</h3>
<p>Life is not monochrome, so add a splash of color. The bright, changeable covers color display of SeiTi Mobile set it apart from other phones, so you can talk in style. Stop planning your life around power outlets. Give SeiTi Mobile a full charge and you will be able to go a week without needing to top up.
The durability function means the SeiTi Mobile can withstand anything life throws at it no matter how long you use it.</p>
 
<h3>SeiTi Mobile Phone Dimensions</h3>
<ul>
<li>Height: 110mm</li>
<li>Width: 44mm</li>
<li>Thickness: 14mm</li>
<li>Weight: 80g</li>
<li>Display size: 1.8</li>
<li>Display features: Red, pink blue</li>
<li>Mp3 Player/MPEG for Videos</li>
<li>Multi Language Support</li>
<li>Dual SIM card</li>
<li>SD Card slot</li>
<li>Flash Light</li>
<li>Bluetooth</li>
</ul>


<p>Life is better with high-lever soundtrack. With powerful good speaker and professional multimedia technology, SeiTi Mobile T535 performs  brilliantly in respect to that. The external memory allows you to store more music you love. You no longer need an alternative MP3 player any more. Play your music instantly, anywhere with SeiTi Mobile</p>
<p>Hate failed calls? Want faster reception? SeiTi Mobile does exactly what you need. It features strong signal and better reception. The longer lasting battery carries enough energy to power you through your tasks. And the wireless FM provides you with cost-free audio entertainment.</p>

  </div>
	<div class="col main-sidebar"  style="border: solid 1px #c3c3c3;">
	<?php include 'sidebar.php'?>
</div>
</div>
  </div>
  </div>
  </body>