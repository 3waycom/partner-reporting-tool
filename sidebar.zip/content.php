<link href="css/styles.css" rel="stylesheet">
<div class="section group">
	<div class="col span_1_of_3">
    <center>
    <img src="images/nis.jpg" width="74" height="64" alt="" />
	<h4>Nischint</h4>
<hr style="width: 70px"; color="#FF0000" />
    <p>Nischint is the most advanced parental guidance and a unique software application service designed to support parents in their quest to provide the best level of information on digital media across all devices.</p>
<p><a href='Nischint.php' class='button'>Read More</a></p>
</center>
	</div>
	<div class="col span_1_of_3">
    <center>
    <img src="images/music.jpg" width="74" height="64" />
<h4>Callertunes</h4>
    <hr style="width: 70px"; color="#FF0000" />
    <p>This is a service that offers phone users the ability to personalize their ring back tones. By default, phones plays a tring-tring tone. This ability has opened new business opportunities.</p>
<p><a href='callertunes.php' class='button'>Read More</a></p>
</center>
	</div>
	<div class="col span_1_of_3">
    <center>
    <img src="images/apps.jpg" width="74" height="64" />
<h4>Application Development</h4>
   <hr style="width: 70px"; color="#FF0000" />
    <p>An app, is a software designed to run on a mobile device, such as a smartphone or tablet. Applications frequently serve to provide users with similar services to those accessed on PCs.</p>
<p><a href='Mobile_Applications.php' class='button'>Read More</a></p>
</center>
	</div>
</div>
  </div>
  </div>
      <br />    <br />
<div class="section group">
	<div class="col span_1_of_3">
    <center>
    <img src="images/scode.jpg" width="74" height="64" />
<h4>Shortcodes</h4>
    <hr style="width: 70px"; color="#FF0000" />
    <p>We offers a wide range of SMS services to keep you informed, entertained, and engaged. It can be  purchased by making a phone call, sending a text message, or requesting them via the internet or data connection from your mobile phone...</p>
<p><a href='shortcodes.php' class='button'>Read More</a></p>
</center>
	</div>
	<div class="col span_1_of_3">
    <center>
    <img src="images/myfonetv.jpg" width="74" height="64" />
<h4>MyFone TV</h4>
    <hr style="width: 70px"; color="#FF0000" />
    <p>MyFone TV is a collection of Mobile TV services that allows subscribers stream a rang of both mobile channels and video content on their data enabled  devices. Only subscribers with data enabled handsets, tablets and PC are  eligible for this service.</p>
<p><a href='myfone_tv.php' class='button'>Read More</a></p>
</center>
	</div>
	<div class="col span_1_of_3">
    <center>
    <img src="images/seiti.jpg" width="74" height="64" />
<h4>SeiTi Mobile</h4>
    <hr style="width: 70px"; color="#FF0000" />
    <p>SeiTi W200 gives you up to 12 hours of talk time which you can leave on standby for up to 48 hours. With all that juice in the tank, it keeps going as long as you do. Make a statement with the SeiTi W200. Its bright and simple looks makes it unique.</p>
<p><a href='SeiTi_Mobile.php' class='button'>Read More</a></p>
</center>
	</div>
</div>
  </div>
  </div>
</body>