<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/service-contents.css">
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div><img src="images/rbts.jpg" width="100%" height="auto" alt="callertunes"></div>
<div class="section group">
	<div class="col main-article">
	<h1>Callertunes</h1>
    <p>CallerTunez is the service that 3wc offers to mobile phone users which gives them the ability to personalize their ring back tones. By default, phones plays a “tring-tring” tone. This ability to personalize Ring Back Tones (RBT) has opened new and exciting doors for more business opportunity especially in the music industry.<br>
      Callertunes</p>
    <p>An enhanced and user friendly Caller Tunez is being introduced by 3wc. This will provide customers several ways to subscribe to the service. The service is compatible to all handset types with a valid SIM.</p>
    <p>How It Works</p>
    <p>The customer can buy up to 10 different songs. Just follow any of the steps below to buy and activate your caller tunez according to the network you have:</p>
    <p>FOR MTN: To get Caller Tunez via SMS: Simply type the code of your choice in an sms and send to 4100. N50/tune. E.g For Double wahala by Oritse Femi, text 038795 to 4100<br>
      FOR GLO: To get Caller Tunez via SMS: Simply type tuneXXXX to 7728. Where XXXX represents the code of the desired song. N50/tune. E.g For My Girl by Correction, text “tune042754″ to 7728.<br>
      FOR ETISALAT: To get Caller Tunez via SMS: Simply type the code of your choice in an sms and send to 251. E.g For Olegelege by Presh, text 6664951 to 791.<br>
      FOR AIRTEL: To get Caller Tunez via SMS: Simply type buy XXXX to 791. N50/tune. Where XXXX represents the code of the desired song.</p>
    <p>Billing</p>
    <p>The customer will be billed for Caller Tunez in the following ways:</p>
    <p>Monthly Subscription Fee: The customer will pay N50/month as subscription or access fee in order to access the tunes bought and stored in the Personal Library.</p>
    <p>Caller Tunez Fees: The customer can download his/her choice of Caller Tunez for N50/tune at any time via SMS, IVR or Web, for his/her Personal Library.</p>
    <p>How to Search for CallerTunez Via SMS (MTN ONLY)</p>
    <p> Send reg in an SMS to 4100 to register for Caller Tunez service<br>
      Send help in an SMS to 4100 to get help information about Caller Tunez<br>
      Send cancel in an SMS to 4100 to deregister the Caller Tunez service<br>
      Send del+tunecode in an SMS to 4100 to delete a tune from the Caller Tunez service for example del702439<br>
      Send newtune in an SMS to 4100 to query new tunez from the Caller Tunez service<br>
      Send top10 in an SMS to 4100 to query top 10 songs from the Caller Tunez service</p>
    <p></p>

<div></div>

<div></div>
	</div>
	<div class="col main-sidebar">
	<?php include 'sidebar.php'?>
	</div>
</div>
  </div>
  </div>
  </body>