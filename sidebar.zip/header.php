<meta charset='utf-8'>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
<script src="https://s3.amazonaws.com/menumaker/menumaker.min.js" type="text/javascript"></script>
<script src="css/script.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/styles.css">
<body>
<div align="center"><a href="index.php"><img src="images/3wc_logo.png" width="161" height="76" alt="3wc_logo"></a></div>
<div align="center">
<div id="cssmenu">
  <ul>
     <li><a href="index.php"><i class="fa fa-fw fa-home"></i>HOME</a></li>
     <li><a href="sms-products.php"><i class="fa fa-fw fa-bolt"></i>SERVICES</a>
        <ul>
           <li><a href="shortcodes.php">SMS SERVICES</a>
           <ul>
                 <li><a href="shortcodes.php">SHORTCODES</a></li>
                 <li><a href="#">BULK SMS</a></li>
              </ul>
           </li>
           <li><a href="#">MUSIC</a>
              <ul>
                 <li><a href="callertunes.php">CALLERTUNES</a></li>
                 <li><a href="#">NAME TUNES</a></li>
              </ul>
           </li>
           <li><a href="mnews.php">mCONTENT</a></li>
           <li><a href="mobile_applications.php">MOBILE APPS</a>
              <ul>
                <li><a href="myfone_tv.php">MYFONE TV</a></li>
                 <li><a href="awashopper.php">AWASHOPPER</a></li>
                 <li><a href="Nischint.php">NISCHINT</a></li>
              </ul>
           </li>
           <li><a href="SeiTi_Mobile.php">SEITI MOBILE</a></li>
           <li><a href="Mobile_payments.php">MOBILE PAYMENT</a>
           	<ul>
           		<li><a href="#">DIAMOND YELLOW</a></li>
           		<li><a href="#">MCASH</a></li>
            </ul>
           </li>
           <li><a href="#">IVR</a></li>
           <li><a href="#">MTN FUNDME</a></li>
        </ul>
     </li>
     <li><a href="about_us.php"><i class="fa fa-fw fa-check-square"></i>ABOUT US</a></li>
     <li><a href="contact_us.php"><i class="fa fa-fw fa-phone"></i>CONTACT US</a></li>
  </ul>

</div>
</body>
</div>
</body>