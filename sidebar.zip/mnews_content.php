<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/service-contents.css">
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div><img src="images/mnews-banna.jpg" width="100%" height="auto" alt="callertunes"></div>
<div class="section group">
	<div class="col main-article" style="border: solid 1px #c3c3c3; padding:1%">
<h1>MCONTENT PLATFORM</h1>

<p>Get the news while it's still news - 3WC is at the forefront on innovation in Nigeria, with a continuous focus on technologies that will enhance the lifestyle of our customers.</p>

<p>The latest on 3WC's line-up of such innovative services, is the MCONTENT Platform. This service provides the most up to date news on the local and international scene, sports news, entertainment news, fashion news, Finance news, the latest Job vacancies and more.</p>

Note:

    <p>To use this service, you should have an MMS enabled phone with the right MTN MMS settings. (If you have not received the configurations or have not activated MMS on your mobile phone, text SETTINGS to 3888 for free from your MTN line.</p>
	</div>
	<div class="col main-sidebar"  style="border: solid 1px #c3c3c3;">
	<?php include 'sidebar.php'?>
</div>
</div>
  </div>
  </div>
  </body>