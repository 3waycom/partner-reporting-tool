<link rel="stylesheet" href="css/sidebar.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script> 
$(document).ready(function(){
    $("#flip").click(function(){
        $("#panel").slideToggle("slow");
    });
});

$(document).ready(function(){
    $("#flips").click(function(){
        $("#panels").slideToggle("slow");
    });
});
</script>
<table border="0" cellspacing="0" cellpadding="0" style="padding:1%">
  <tr>
    <td>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
  <div class="inside-3wc">
    <div class="sideba">
<div id="flip" style="cursor:pointer;border-bottom-style: solid; border-bottom-color: #ff0000;"><b>Select 3WC Vas Services:</b></div>
    <div id="panel">
    <p>MTN-FundMe</p>
    <p>Brain Wave</p>
    <p><a href="awashopper.php">Awashopper</a></p>
    <p><a href="myfone_tv.php">MyFone TV</a></p>
    <p><a href="Nischint.php">Nischint</a></p>
    <p>Build Your Business</span></p>
    </div>
</div>
  </div>

  </td>
  </tr>
  <tr>
    <td>
    <div class="inside-3wc">
    	<div class="sideba" style="border-bottom-style: solid; border-bottom-color: #ff0000;">
      <h4>Inside 3wc</h4>
        <p>3Way Communications is a telecom value-added services (VAS) and new media provider offering an array of next-generation mobile solutions based on innovative technologies and service platforms.s</p>
      </div>
  	</div>
    </td>
  </tr>
  <tr>
    <td>
<div id="flips" style="cursor:pointer; border-bottom-style: solid; border-bottom-color: #ff0000;"><b>Our Address</b></div>
<div id="panels" style="border-bottom-style: solid; border-bottom-color: #ff0000;">
<p>2a Itohan Avenue, Awolowo way, Balogun Bus-top, Ikeja, Lagos</p>
<p>Phone Number: 09030000100</p>
<p>Email Address: info@3wc4life.com</p>
</div>
<div style="border-bottom-style: solid; border-bottom-color: #ff0000;">
<p>Like Us On Facebook!</p>
<div class="fb-like" data-href="https://web.facebook.com/3waycom?_rdr" data-width="300" data-layout="standard" data-action="like" data-size="large" data-show-faces="true" data-share="true"></div>
</div>
<br />
<div style="text-align:center; border-bottom-style: solid; border-bottom-color: #ff0000;""> <a href="http://www.3wc4life.net/sms.php"><img src="images/subscribe-now-button.jpg" width="50%" height="auto" /></a> </div>
  	</td>
  </tr>
  <tr>
    <td>

  </td>
  </tr>
</table>