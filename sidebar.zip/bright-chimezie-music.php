<!doctype html>
<html>
<head>
<link href='https://fonts.googleapis.com/css?family=Inconsolata|Dosis' rel='stylesheet' type='text/css'>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Untitled Document</title>
</head>

<body style="font-family: 'Dosis', sans-serif;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <th scope="col"><img src="images/3wc_logo.jpg" width="200" height="100"></th>
  </tr>
  <tr>
    <td><?php include 'bright-chumezie.php'?></td>
  </tr>
  <tr>
    <th colspan="6" scope="col"><p style="font-weight: lighter; color: #000; font-size:10px">Copyright 2016 | 3way Communications | Powered by 3WC | <a href="http://www.3wc4life.net/terms.php" style="font-weight: lighter; color: #000; font-size:10px; text-decoration:none; color:#000">Terms and Conditions</a> | <a href="http://www.3wc4life.net/privacy-policy.php" style="font-weight: lighter; color: #000; font-size:10px; text-decoration:none; color:#000">Privacy Policy</a> | <a href="http://www.3wc4life.net/contact_us.php" style="font-weight: lighter; color: #000; font-size:10px; text-decoration:none; color:#000">Contact Us</a></p></th>
  </tr>
</table>

</body>
</html>