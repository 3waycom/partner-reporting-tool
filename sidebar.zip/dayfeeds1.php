<?php header('Content-Type: text/xml; charset=ISO-8859-1'); ?>
<?php
include('Connections/conn.php');
include('reformat_text.php');

$fedcat = $_GET['sid'];

		$mtime = (date(DATE_RFC822));

		$tdate = date("Y-d-m");

//header("Content-type: text/xml");



		$sql1=mysql_query("SELECT * FROM goalcomrss WHERE actdate='$tdate' and feedcategory=\"$fedcat\" ORDER by transid DESC, s_no ASC LIMIT 1");	

	

		while($fet1=mysql_fetch_array($sql1)){

			$id=$fet1['id'];

			$feedtitle=$fet1['feedtitle'];

			$feeddescript=$fet1['feeddescript'];

			$contid=$fet1['contid'];

			$conttitle=$fet1['conttitle'];
			

			 $contdescript1=utf8_decode($fet1['contdescript']);

			// $contdescript1 = preg_replace("/[\/]/", "_", str_replace(" ", "", strtolower($contdescript1)));

			$contlink=$fet1['contlink'];

			$pubdate=$fet1['pubdate'];

			

			//$mtime = date("Y-d-m H:m:s");

			//echo $pubdate = date("Y-d-m H:m:s",strtotime($pubdate)); 

			$pubdate = date("Y-m-d H:m:s",time()); 

$repdata =  

	"<item>"."\n".

	"<title>".$conttitle."</title>"."\n".

	"<description>". htmlspecialchars($contdescript1)."</description>"."\n".

	"<link></link>"."\n".

	"<guid isPermaLink=\"false\">".$contid."</guid>"."\n".

	"<pubDate>". $pubdate ."</pubDate>"."\n".

	"</item>"."\n";

	

	//  if ($contdescript != ''){

	//	  $repdata1 .= $repdata."\n"; 

	//  }

	}



	 $data =  

    "<rss version=\"2.0\">".

	"<channel>"."\n".

	"<title>".$feedtitle."</title>"."\n".

	"<description>".$feeddescript."</description>"."\n".

	"<link></link>"."\n".

	"<lastBuildDate>". $pubdate ."</lastBuildDate>"."\n".

	"<pubDate>". $pubdate ."</pubDate>"."\n".

	"		$repdata\n".

	"</channel>\n".

	"</rss>\n"; 



//$fedcat1 =str_replace(" "\n"; 



//$fedcat1 =str_replace(" ", "", $fedcat);

//$fh=fopen("feeds/".$fedcat1.".rss","w");

//fwrite($fh,$data);

//fclose($fh);



echo $data;

?>