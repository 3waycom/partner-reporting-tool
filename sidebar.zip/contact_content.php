<script src='https://www.google.com/recaptcha/api.js'></script>
<script src="http://maps.googleapis.com/maps/api/js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/service-contents.css">
<body>
<script src="http://maps.googleapis.com/maps/api/js"></script>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
</script>
<div><img src="images/contact-us.gif" width="100%" height="auto" alt="callertunes"></div>
<div class="section group"> <!--overall opening tag-->
<div class="col main-article" style="border: solid 1px #c3c3c3; padding:1%"><!--maincontent-->
<?php
if ( isset( $_POST['Submit1'] ) ){ 

	if(isset($_POST['name'])){
          $name=$_POST['name'];
    }if(isset($_POST['email'])){
          $email=$_POST['email'];
    }if(isset($_POST['message'])){
          $message=$_POST['message'];
    }if(isset($_POST['g-recaptcha-response'])){
          $captcha=$_POST['g-recaptcha-response'];
        }
	if(!$captcha){
          echo '<h2 style="color:red">Please check the captcha form!.</h2>';
        }
	if (($name=="")||($email=="")||($message=="")||($captcha != TRUE))
		{
          echo '<p style="color:red">All fields are required including the robot verification.</p>';
         }
		 else{
			 $response=file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=6LeKlykTAAAAAATfYHUPORYll2rvDpGc67rd2mEU&response=".$captcha."&remoteip=".$_SERVER['REMOTE_ADDR']);
			 if($response.success==false)
			{
			echo '<h2>You are spammer ! Get the @$%K out</h2>';
			}else
			{
			$from="From: $name<$email>\r\nReturn-path: $email";
			$subject="Message sent from 3wc Mail Application!";
			$message=$_POST['message'];
			mail("info@3wc4life.com,aezekiel@3wc4life.com", $subject, $message, $from);
			echo '<p style="color:green"><b>Your Message has been recieved. We will get back to you within 48 hours!</b></p>';
			}
		 }
}
?>
    <form  action="" method="POST">
    <p>Your name:</p>
    <input name="name" type="text" value="" size="30"/>
    <p>Your email:<p>
    <input name="email" type="text" value="" size="30"/>
    <p>Your message:<p>
    <textarea name="message" rows="7" cols="30"></textarea>
    <br>
	<div class="g-recaptcha" data-sitekey="6LeKlykTAAAAAATfYHUPORYll2rvDpGc67rd2mEU"></div>
	<br>
    <input type="submit" name="Submit1" value="Send Us A mail Now"/>
    </form>
<div>
<br>
<script src='https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyBLSvD4-wT7YHDjuarFGNLsDyP0iSMTvQM'></script><div style='overflow:hidden;height:400px;max-width:520px;'><div id='gmap_canvas' style='height:400px;max-width:520px;'></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style></div> <a href='https://add-map.org/'>google map widget for website</a> <script type='text/javascript' src='https://embedmaps.com/google-maps-authorization/script.js?id=0070e2f7e62d3d89e3f0235eb702aa7b08dda2f4'></script><script type='text/javascript'>function init_map(){var myOptions = {zoom:11,center:new google.maps.LatLng(6.6041422,3.3418497000000116),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById('gmap_canvas'), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(6.6041422,3.3418497000000116)});infowindow = new google.maps.InfoWindow({content:'<strong>3way Communications Ltd</strong><br>2a Itohan Avenue Ikeja<br> Lagos<br>'});google.maps.event.addListener(marker, 'click', function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>
</div>
<div>
  	<h3>Our Customer Care Line;</h3>
  <p>Please Call: 09030000108<br></p>
  <br>
  	<h3>For Callertunes and SMS Service</h3>
  <p>Please Call: 07033195773</p>
  <br>
</div>
  </div> <!--maincontent close-->
<div class="col main-sidebar"  style="border: solid 1px #c3c3c3;">
	<?php include 'sidebar.php'?>
</div>
  </div><!--overall closing tag-->
  </body>