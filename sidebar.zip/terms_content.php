<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/service-contents.css">
<style type="text/css">
<!--
p.MsoNormal {
margin-top:0in;
margin-right:0in;
margin-bottom:8.0pt;
margin-left:0in;
line-height:107%;
font-size:11.0pt;
font-family:"Calibri","sans-serif";
}
-->
</style>
<body>
<div id="fb-root"><img src="images/terms-and-conditions.jpg" width="100%" height="auto"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div></div>
<div class="section group">
	<div class="col main-article" style="width:100%">
	  <h1><strong>TERMS AND CONDITIONS </strong></h1>
      <p><strong>GENERAL </strong> <br>
      3Way Communications Limited (3WC)  may at its sole discretion modify this agreement at any time, and such modifications  will be effective immediately upon posting. By using services provided by 3WC,  you are agreeing to be bound by the terms and conditions below (&quot;Terms of  Use&quot; or &quot;Terms&quot;). </p>
      <p><strong>Intellectual Property </strong> <br>
        <strong>A. </strong>Intellectual property (including copyright and trademarks in  the materials and Services) other than those belonging to any person,  organization, company or group displaying, listing or advertising in the  Services are owned by 3Way Communications Limited or its partners or affiliates  (unless otherwise indicated) and you agree not to infringe on any intellectual  property rights owned by 3Way Communications Limited or anyone else. <br>
        <strong>B. </strong>Nothing contained in the Services (including granting you  access to the Services) should be construed as granting any license or right to  use any intellectual property displayed in the Services without the express  written consent of 3Way Communications Limited. </p>
      <p><strong>Use of Information in the Services </strong> <br>
        <strong>A. </strong>Information contained in the Services is for your personal  use only and may not be sold, redistributed or used for any commercial purpose  (other than to correct or add information contained in the Services) including,  but not limited to, the use of any business contact details for unsolicited  commercial correspondence or the creation of customer lists. Any commercial use  of this information requires the written consent of 3Way Communications  Limited. You may download material from the Services for your personal,  non-commercial use only, provided you keep intact all copyright and other  proprietary notices. <br>
        <strong>B. </strong>You may not modify, copy, reproduce, republish, upload,  post, data-mine, scrape, transmit or distribute in any way any material from  3Way Communications Limited or the Services including code and software. You  must not use the Services for any purpose that is unlawful or prohibited by  these Terms of Use. </p>
      <p><strong>Security, Access &amp; Accuracy of  Information </strong> <br>
        <strong>A. </strong>While 3Way Communications Limited takes all reasonable  efforts to ensure the protection, privacy and integrity of any information you  may provide, no data transmission over the internet is totally secure and the  possibility exists that this information could be unlawfully used or observed  by a third party while in transit over the internet or while stored on 3Way  Communications systems or in the Services. To the extent permitted by law, 3Way  Communications Limited disclaims all liability to you under the law should this  occur. <br>
        <strong>B. </strong>As part of the Services, 3Way Communications Limited may  respond to user requests or provide information (such as business information  requested by users) to users, by any of the following means: <br>
        <strong>i. </strong>Verbally; <strong>ii. </strong>Connecting a user directly to a  business via telephone; <strong>iii. </strong>By sending an SMS message to the user; <strong>iv. </strong>By email; <strong>or v. </strong>Over the internet, mobile phone application or other  technological device. <br>
        <strong>C. </strong>3Way Communications Limited cannot give you any guarantee of  the accuracy of any business information or entity contained in the Services,  including but not limited to the availability of any special offer set out in  any listing. <br>
        <strong>D. </strong>You are responsible for obtaining all necessary equipment  and services equipment required to access and use the services. </p>
      <p><strong>Links to other Websites, Business  and Services </strong> <br>
        <strong>A. </strong>In your use of the Services, you may access content from  third parties (&quot;Third Party Content&quot;) via links to other websites or  other forms of contact. 3Way Communications Limited does not control Third  Party Content and makes no representations or warranties about it. 3Way  Communications Limited does not accept any liability for the reliability,  completeness or accuracy of any Third Party Content or for the privacy  practices of the Providers of Third Party Content. You agree that by using the  Services, you may be exposed to Third Party Content that could be false,  offensive, indecent or otherwise objectionable. Under no circumstances will  3Way Communications Limited be liable in any way for any Third Party Content,  including, without limitation, any errors or omissions in any Third Party  Content or any loss or damage of any kind incurred as a result of the use of  any Third Party Content posted, stored or transmitted via our Service. You  agree that you must evaluate, and bear all risks associated with, Third Party  Content. 3Way Communications Limited reserves the exclusive right in its sole  discretion to add, decline or remove, without warning, any content, icon, link  or other connection to Third Party Content. <br>
        <strong>B. </strong>By using 3Way Communications Limited or the Services, you do  not receive any ownership rights in the Third Party Content. You may not use,  access or allow others to use or access the Third Party Content in any manner  not permitted under the Terms, unless you have been specifically permitted to  do so by 3Way Communications Limited or by the owner of that Third Party  Content, in a separate agreement. <br>
        <strong>C. </strong>Accessing Third Party Content from the Services should not  be construed as granting any right or license to use Third Party Content. </p>
      <p><strong>Governing Law </strong> <br>
        <strong>A. </strong>These Terms of Use are governed by and interpreted in  accordance with the laws of Nigeria. You irrevocably and unconditionally submit  to the exclusive jurisdiction of the Courts of Nigeria and waive any objection  to legal action being brought in those Courts on the grounds of venue or  inconvenient forum. <br>
        <strong>B. </strong>The invalidity or unenforceability of any of these Terms of  Use will not affect the validity or enforceability of any other of these Terms,  all of which will remain in full force and effect. <br>
        <strong>C. </strong>Any notice to 3Way Communications Limited must be sent by an  email to info@3wc4life.com <br>
        <strong>D. </strong>Any dispute or difference arising between the Parties with  regard to this Agreement shall be first settled by negotiation. Should such  negotiations fail, either Party shall refer the dispute to arbitration.  Arbitration shall be in accordance with the provisions of the Lagos State  Arbitration Law 2009. </p>
      <p><strong>User Submissions </strong> <br>
        <strong>A. </strong>For any submission of content that you make, you warrant  that you own or otherwise have all rights necessary to license the content you  submit and that the posting and use of your content by us will not infringe or  violate any law or the rights of any third party. You further agree to  indemnify and hold harmless 3Way Communications Limited against any and all  claims, damages, legal fees and any other cost that may be incurred by 3Way  Communications Limited as a result of breaching this warranty. <br>
        <strong>B</strong>.  By submitting any content to our Services, you hereby grant us a perpetual,  worldwide, non-exclusive, royalty-free right and license to use, reproduce,  display, perform, adapt, modify, distribute, have distributed and promote such  content in any form, in all media now known or hereinafter created, anywhere in  the world, and for any purpose including the waiver of any rights in your  contribution. <br>
        <strong>C. </strong>Any content submitted to our Services may also be provided  to or located at third party computers' servers, websites or services. <br>
        <strong>D. </strong>You are solely responsible for any content that you submit  post or transmit via or to our Services. <br>
        <strong>E. </strong>You agree not to post or submit anything to the services  that: <br>
        <strong>1. </strong>May contain any computer viruses,  viruses or other types of harmful code including anything that compromises the  security of the Services or may interfere, disrupt, damage or destroy any  information, files or devices that belong to 3Way Communications Limited <br>
        <strong>2. </strong>May denigrate any ethnic, racial,  sexual or religious group by stereotypical depiction or otherwise; <br>
        <strong>3. </strong>Contains sexually explicit content; <br>
        <strong>4. </strong>Is defamatory; <br>
        <strong>5. </strong>Makes use of offensive language or  images; or <br>
        <strong>6. </strong>Characterizes violence as  acceptable, glamorous or desirable. <br>
        <strong>F. </strong>3Way Communications Limited has no obligation to post any  content that you or anyone else submits. In addition3Way Communications Limited  may, in its sole and unfettered discretion, edit, remove or delete any content  that you post or submit. </p>
      <p><strong>Representations and Warranties </strong> <br>
        <strong>A. </strong>You hereby represent and warrant to us that: <br>
        <strong>i. </strong>you have the full power and authority to enter into  agreements and perform acts under these Terms. <br>
        <strong>ii. </strong>Your use of our Services will not infringe the copyright,  trademark, right of publicity or any other legal right of any third party. and <br>
        <strong>iii. </strong>You will comply with all applicable laws in using our  Services and in engaging in all other activities arising from, relating to or  connected with these Terms, including, without limitation, contacting other  users of the Services. </p>
      <p><strong>Discontinuity of Service </strong> <br>
        <strong>A. </strong>3Way Communications Limited reserves the right at any time  to modify or discontinue, temporarily or permanently, any and/or all portion of  our Services with or without prior notice. You agree that 3Way Communications  Limited will not be liable to you or to any third party for any modification or  discontinuance of our Services. </p>
      <p><strong>Disclaimer of Warranties </strong> <br>
        You hereby agree that: <br>
  <strong>A. </strong>If you use our Services, you do so at your own and sole  risk. Our Services are provided on an &quot;as is&quot; and &quot;as  available&quot; basis. 3Way Communications Limited expressly disclaims all  warranties of any kind, whether express or implied, including, without  limitation, implied warranties of merchantability, fitness for a particular  purpose and non-infringement. <br>
  <strong>B. </strong>3Way Communications Limited does not warrant or guarantee  that <br>
  <strong>i. </strong>Our services will meet your requirements. <br>
  <strong>ii. </strong>Our services will be uninterrupted, timely, secure, or  error-free. <br>
  <strong>iii. </strong>Any information that you may obtain on our services will be  accurate or reliable. <br>
  <strong>iv. </strong>The quality of any products, services, information or other  material purchased or obtained by you through our services will meet your  expectations. <br>
  <strong>v. </strong>Any information you provide or 3Way Communications Limited  collects will not be disclosed to third parties. <br>
  <strong>vi. </strong>Any information available on or through the services will be  free of infection by viruses, worms, Trojan horses or anything else with  destructive properties <br>
  <strong>vii. </strong>The information provided to you by 3Way Communications  Limited will be free of any technical or other mistakes, inaccuracies or  typographical errors. <br>
  <strong>viii. </strong>Any errors in any data or software will be corrected by us  or by third parties who provide such data or software such as maps. <br>
  <strong>ix. </strong>That the information available on or through the Services  will not contain material which some individuals may deem objectionable. or <br>
  <strong>x. </strong>That the functions or services performed by the Services  will be uninterrupted or error-free or that defects in Service will be  corrected. It is the sole responsibility of the user to isolate software and information,  execute anti-contamination software and otherwise take steps to ensure that  software or information, if contaminated or infected, will not damage the  user's information or system. <br>
  <strong>C. </strong>If you access or transmit any content through the use of our  Services, you do so at your own discretion and your sole risk. You are solely  responsible for any loss or damage to you in connection with such actions. and <br>
  <strong>D. </strong>No data, information or advice obtained by you in oral or  written form from us or through or from our Services will create any warranty  not expressly stated in these terms. </p>
      <p><strong>Indemnity </strong> <br>
        You agree to defend, indemnify and  hold 3Way Communications Limit and its officers, directors and employees  harmless from any claim, demand, action, damage, loss, cost or expense,  including without limitation, reasonable attorney's fees, incurred in  connection with any suit or proceeding brought against us arising out of your  use of the Services or alleging facts or circumstances that could constitute a  breach of any provision of these Terms of Use by you. If you are obligated to  indemnify us, 3Way Communications Limit will have the right, in its sole and  unfettered discretion, to control any action or proceeding and determine  whether 3Way Communications Limit wish to settle it, and if so, on what terms. <br>
        3Way Communications Limited®  Additional Terms and Conditions of Use for All Business Listings and  Advertisers </p>
      <p><strong>Additional Terms and Conditions of  Use </strong> <br>
        These additional terms and  conditions of use (&quot;Additional Terms&quot;) apply to all businesses who  have or requested to have their business details supplied to 3Way  Communications Limit and/or listed on the Services, including free business  listings, as well as to all others who choose to advertise with 3Way Communications  Limit, and/or on the Services (together in these Additional Terms defined as  &quot;Advertisers&quot; or &quot;you&quot;). <br>
        In conjunction with the Terms of  Use, these Additional Terms govern all Advertiser's use of the business listing  and finding service, that allow Advertisers to register and/or list your  business with 3Way Communications Limit so that users may locate your business  when users make certain relevant queries to 3Way Communications Limited as well  as any other form of advertising with 3Way Communications Limited (together  &quot;Advertising Services&quot;). Advertising Services include, but are not  limited to, displaying certain information about your business from time to  time, transferring or diverting calls to you and sending certain information to  users of 3Way Communications Limit through various methods such as SMS messages  or IVR. <br>
        These Additional Terms form an  integral part of the above mentioned Terms of Use and all Advertisers must read  these Additional Terms in conjunction with the Terms of Use. The definitions  provided in the above Terms of Use also apply to these Additional Terms and  reference to the Terms of Use herein includes reference to the Additional  Terms. Moreover, the Advertising Services form part of the Services as defined  in the above Terms of Use. As such, everything that applies to Services should,  for the purposes of these Additional Terms, be read to also apply equally to  Advertising Services irrespective of whether Advertising Services are mentioned  separately to Services. <br>
        Please also note that further terms  and conditions for Advertising Services may be contained in approved order  forms and invoices for Advertising Services, promotional and other  documentation provided to you by 3Way Communications Limit or its authorized  resellers (&quot;Resellers). <br>
        3Way Communications Limited may at  its sole discretion modify these Additional Terms at any time, and such  modifications will be effective immediately upon posting the modified agreement  on the Site. These Terms must be accepted and complied with by all who use the  Services in any way. </p>
      <p><strong>Fees and Payments </strong> <br>
        <strong>A. </strong>You agree to pay all applicable fees and charges incurred by  you or any third party using your account (whether or not authorized by you) at  the applicable billing rate during the period in which such fees and charges  were incurred, including, but not limited to applicable taxes, and charges for  any products or services offered for sale through the Advertising Service. <br>
        <strong>B. </strong>Except where otherwise specifically stipulated within these  Additional Terms, you will be responsible for all charges associated with  accessing and maintaining a connection to the Services in general (for example,  charges imposed by an internet access provider, or your local telephone  company). <br>
        <strong>C. </strong>3Way Communications Limited may offer a number of payment  methods and cancellation options. These options allow subscribers to pay for  and opt out of the service. <br>
        <strong>D.</strong> VAT and any other applicable taxes will be  charged for any service purchased from 3Way Communications Limited. </p>
<p class="MsoNormal" style="line-height:normal;">&nbsp;</p></div>
</div>
  </div>
  </body>