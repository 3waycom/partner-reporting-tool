<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/service-contents.css">
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div><img src="images/awashopper-bana.jpg" width="100%" height="auto" alt="callertunes"></div>
<div class="section group">
	<div class="col main-article" style="border: solid 1px #c3c3c3; padding:1%">
<h1>Awashopper</h1>

<p>Awashopper is a location based service that offers a multichannel marketing platform that allows business owners (Merchants) to engage customers.
It enables the merchant to have access to a lot more customers than he would have had otherwise, and does it in a more cost effective manner.</p>

<h2>What is the Service meant to accomplish?</h2>

<p>To the Merchants, Awashopper is meant to:</p>
<ul>
<li>help them showcase their goods and services by creating and launching real time or scheduled offers</li>
<li>increase customers’ patronage</li>
<li>increase sales and</li>
<li>reduce cost </li>
</ul>

<p>For the Customers, Awashopper is meant to:</p>
<ul>
<li>Search for businesses nearby and look up addresses, phone numbers, opening hours and other business information.
<li>Discover, save and claim offers from your favorite local businesses with your mobile device.
</ul>


<h2>Awashopper for Businesses (A Merchants Action Point)</h2>
<p>To get potential customers, all you need to do is keep your online and mobile presence up-to-date. This allows you to acquire new customers and boost your sales with scheduled or real-time campaigns and targeted offers. You can also:</p>

<ul>
<li>Browse & edit offers (active, past & upcoming)</li>
<li>View real time statistics</li>
<li>Generate campaign reports</li>
<li>Manage your Account</li>
</ul>

<h3><b>NOTE:</b>  Step 2 includes the following mandatory things:</h3>

<ul>
<li>Reduced price and Normal Price</li>
<li>Short title for the Offer</li>
<li>Longer description for the Offer</li>
<li>Choose a category for the offer</li>
<li>Set the start and end date for the offer
<li>Upload a picture (optional), where pictures can be taken and saved in your phone or computer before upload.</li>
<li>Specify the time of day when the offer can be redeemed</li>
</ul>


<h2>FAQs for AWASHOPPER </h2>
<p>Q: What is Awashopper?</p>
<p>A: Awashopper is a multichannel marketing platform that allows business owners (Merchants) to engage customers (any interested buyer).</p>
--
<p>Q: Who need this service?</p>
<p>A: Owners of small and medium businesses. Generally for sellers of goods and services that attract public patronage.</p>
-- 
<p>Q: Why do I need the service?</p>
<p>A: As a Merchant: It enables you to have access to a lot more customers than he would have had otherwise, and does it in a more cost effective manner.
As a Customer: It allows them to enjoy new and discounted offers making them feel like you are just in their neighborhood -with little or no stress at all. It also offers the opportunity of having choice goods delivered at home promptly and at very low cost.</p> 
-- 
<p>Q: As a Merchant, how can I pay for the service to sign up?</p>
<p>A:  (a)Payment can be made by texting a keyword (to be provided) to a short code (to be provided) using your phone and the required money will be deducted.
(b) Merchants can also use other POS channels or e-money transfer into a designated bank account.</p>
-- 
<p>Q: As a Merchant, can I get out of the service at anytime?</p>
<p>A:  Yes, you can unsubscribe from the service anytime.</p>
-- 
<p>Q: How much does this service cost?</p>
<p>A: The service costs 0ne thousand naira only (N1000.00) monthly after a free trial period of 30 days.</p>
-- 
<p>Q: How can people use the service?</p>
<p>A: Merchants can use the service by:
	<ul>
	<li>Talking to a Field Sales Agent (FSA) who will take you through the Sign-up Process and</li>
	<li>Create Active Offers</li>
	</ul>
</p>
-- 
<p>Q: What are Offers?</p>
<p>A:  Offers are the products (items) you want to put on the portal for your customers to see and buy. They usually come with their original price and a discount price, your operation days and hours, the location address of your business and contact phone numbers. It also comes with an expiry date.</p>
-- 
<p>Q: How do I sign up as a Merchant?</p>
<p>A:  It’s easy! Our Field Agent will assist you by creating an Account for you on the portal, activating your Subscription plan and you will finish by creating offers for your customers.</p>
-- 
<p>Q: Can I access the service with a Phone, and is it possible with any phone?</p>
<p>A: YES. However, the phone must be one that can browse (WAP enabled).</p>
-- 
<p>Q: How do I measure the success of my campaign?</p>
<p>A: As a merchant, every time you login to your Awashopper account, you will see the number of viewers who visited your offer by clicking on My Offer tab.</p>
-- 
<p>Q: How can I get my money from a customer for items purchased?</p>
<p>A: Payment can be made by the customer through the following options:
 (a) On the counter if they have go to the merchant’s location,
 (b) With a credit card or other forms of fund transfer stated on your page.
 (c) Pay on Delivery</p>
-- 
<p>Q: Can the product be delivered to my customer at hom</p>e?</p>
<p>A:  Yes
-- 
<p>Q: Who do I contact when I encounter a problem?</p>
<p>A: Call 09030000100<p>

    </div>
	<div class="col main-sidebar"  style="border: solid 1px #c3c3c3;">
	<?php include 'sidebar.php'?>
</div>
</div>
  </div>
  </div>
  </body>