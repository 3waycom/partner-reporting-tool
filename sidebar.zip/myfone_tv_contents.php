<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/service-contents.css">
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div><img src="images/myfone-banna.jpg" width="100%" height="auto" alt="callertunes"></div>
<div class="section group">
	<div class="col main-article" style="border: solid 1px #c3c3c3; padding:1%">
<h1>MyFone TV</h1>

<p>MyFone TV is a collection of Mobile TV services that will allow subscribers stream a rang of both mobile channels and video streaming content on their data enabled devices. Only subscribers with data enabled handsets, tablets and PC are eligible for this service. MyFone TV allows subscribers activate this capability using their WAP browser on their mobile device, by either accessing the Mobile TV packages viahttp://www.myfonetv.com or subscribing via shortcode. The service will provide target market designed, bouquets from which the subscriber may choose from, and experience the best view on the go.</p
 
 
><h2>For Mobile</h2>
Download the Android app and install MyFoneTV shortcut from http://www.myfonetv.com Register and start watching live TV on your mobile 3G/4G or WiFi internet connection. A Compatible device, data plan and a MyFoneTV plan is required. All smart phones are supported especially Android and iOS devices.
There are four TV bouquets each with daily, weekly and monthly subscription plans. Then there are the special or thematic plans as well which feature as a one-off daily purchase. Mobile Operator charges may apply especially for plan purchase and cellular data usage.
Service is available wherever there is internet or cellular data coverage.
 
<h2>For PC</h2>
If you are using a PC, simply visit http://www.myfonetv.com on your PC browser, register, purchase a bouquet and start watching live TV on your PC with WiFi internet connection! A Computer, an internet browser e.g. Firefox, WiFi internet and a MyFoneTV plan is required.

	</div>
	<div class="col main-sidebar"  style="border: solid 1px #c3c3c3;">
	<?php include 'sidebar.php'?>
</div>
</div>
  </div>
  </div>
  </body>