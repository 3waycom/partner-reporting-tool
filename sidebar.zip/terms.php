<!doctype html>
<html>
<head>
<link href='https://fonts.googleapis.com/css?family=Inconsolata|Dosis' rel='stylesheet' type='text/css'>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>3way Communications Ltd | Terms | SMS, CRBT, Subscription, Phones, applications, Softwares, mtn, glo, etisalat, airtel, mobile, mns, huawei, nigeria, 3wc, 3way, communications, network, tele communications</title>
</head>
<body style="font-family: 'Dosis', sans-serif;">
<table width="80%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <th scope="col"><?php include 'header.php'?></th>
  </tr>
  <tr>
    <td><?php include 'terms_content.php'?></td>
  </tr>
  <tr>
    <td><?php include 'footer.php'?></td>
  </tr>
  <tr>
    <td></td>
  </tr>
</table>

</body>
</html>
