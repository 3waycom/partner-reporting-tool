<link rel="stylesheet" href="css/button.css">
<body>
<a href="#" class="hvr-curl-bottom-right">Curl Bottom Right</a>
</body>