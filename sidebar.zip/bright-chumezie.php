<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<th scope="col">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<th scope="col" align="center">
<h1>BECOME A FAN</h1>
</th>
</tr>
<tr>
<th scope="col" align="center"><img class="artiste-img" alt="BRACKET" src="images/bright-chimezie.png" width="420" height="320" /></a></th>
</tr>
<tr>
<td align="center"><iframe src="http://callertunez.mtnonline.com/user/userdowntone.screen?toneID=18190153&toneCode=1038990&toneName=QkVDQVVTRSBPRiBFTkdMSVNI&singerName=QlJJR0hUIENISU1FWklF&toneLanguage=4&desc=M3dj&price=20&toneValidDay=2050-12-27%2023:59:59&spName=M1dD&updateTime=2016-02-12%2016:02:53&downTimes=0&relativeTime=7&tonePath=http://41.220.77.92:9998/colorring/al/601/038/0/0000/0001/629.wav&ltonecode=601038000000001629&tonename=QkVDQVVTRSBPRiBFTkdMSVNI&singer=QlJJR0hUIENISU1FWklF&uploadType=1&spCode=601038&type=&xmlfile=browsebyname&submenu=user_browse_rbts_byname&urlflag=null&hotCode=%20&cutflag=0&relativeDate=&downloadDate=&priceGroupId=-1&searchPage=undefined" height="340" width="420" allowfullscreen="" frameborder="0"></iframe></td>
</tr>
<tr>
<td align="center">
<table width="420" border="0" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<th scope="col" align="left">MTN subscribers download instruction;
<ol>
	<li>Enter your phone Number below and click "DOWNLOAD".</li>
	<li>Click "FORGET PASSWORD" to receive a unique code on your phone.</li>
	<li>Enter the new code as your password.</li>
	<li>Click "CONFIRM" to be a fan immediately. ITS FREE!</li>
</ol>
<p style="text-align:center; font-size:24px; color:#F00; padding:5px">Click on the codes below to subscribe!</p></th>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td align="center"><style type="text/css"><!--
.tg  {border-collapse:collapse;border-spacing:0;} .tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;} .tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;} .tg .tg-h1ue{background-color:#3166ff;vertical-align:top; color: white;} .tg .tg-92gg{text-decoration:;background-color:#f8ff00;vertical-align:top} .tg .tg-gqqr{text-decoration:;background-color:#fe0000;vertical-align:top; color:white} .tg .tg-ctfk{text-decoration:;background-color:#34ff34;vertical-align:top;color:red;} .tg .tg-yw4l{vertical-align:top}
--></style>
<table class="tg" width="297" align="center">
<tbody>
<tr>
<th class="tg-h1ue" width="170">SONG NAME</th>
<th width="115" align="left" class="tg-92gg">MTN</th>
</tr>
<tr>
<td class="tg-yw4l"> AFRICAN STYLE</td>
<td class="tg-yw4l"><a href="sms:4100?body=0038715" style="color:#F69"><u>Click here</u></a></td>
</tr>
<tr>
<td class="tg-yw4l">BECAUSE OF ENGLISH</td>
<td class="tg-yw4l"><a href="sms:4100?body=1038990" style="color:#F69"><u>Click here</u></a>
</td>
</tr>
<tr>
<td class="tg-yw4l">BECAUSE OF ENGLISH2</td>
<td class="tg-yw4l"><a href="sms:4100?body=1038991" style="color:#F69"><u>Click here</u></a></td>
</tr>
<tr>
<td class="tg-yw4l">I GOT THE RYTHM</td>
<td class="tg-yw4l"><a href="sms:4100?body=1038992" style="color:#F69"><u>Click here</u></a></td>
</tr>
<tr>
  <td class="tg-yw4l" style="background-color: #3166ff; color: #fff;">SONG NAME</td>
  <td class="tg-yw4l" style="color: #fff;" bgcolor="#FF0000">AIRTEL</td>
</tr>
<tr>
<td class="tg-yw4l">AFRICAN STYLE</td>
<td class="tg-yw4l"><a href="sms:791?body=0579401" style="color:#F69"><u>Click here</u></a></td>
</tr>
<tr>
<td class="tg-yw4l">BECAUSE OF ENGLISH</td>
<td class="tg-yw4l"><a href="sms:791?body=0579402" style="color:#F69"><u>Click here</u></a></td>
</tr>
<tr>
<td class="tg-yw4l">BECAUSE OF ENGLISH2</td>
<td class="tg-yw4l"><a href="sms:791?body=0579403" style="color:#F69"><u>Click here</u></a></td>
</tr>
<td class="tg-yw4l" style="background-color: #3166ff; color: #fff;">SONG NAME</td>
  <td class="tg-yw4l" style="color: #fff;" bgcolor="#00CC00">ETISALAT</td>
</tr>
<tr>
<td class="tg-yw4l">AFRICAN STYLE</td>
<td class="tg-yw4l"><a href="sms:251?body=82636" style="color:#F69"><u>Click here</u></a></td>
</tr>
<tr>
<td class="tg-yw4l">BECAUSE OF ENGLISH</td>
<td class="tg-yw4l"><a href="sms:251?body=82637" style="color:#F69"><u>Click here</u></a></td>
</tr>
<tr>
<td class="tg-yw4l">BECAUSE OF ENGLISH2</td>
<td class="tg-yw4l"><a href="sms:251?body=82638" style="color:#F69"><u>Click here</u></a></td>
</tr>
<tr>
<td class="tg-yw4l">I GOT THE RYTHM</td>
<td class="tg-yw4l"><a href="sms:251?body=82639" style="color:#F69"><u>Click here</u></a></td>
</tr>
</table>
</td>
</tr>
</tbody>
</table>
</th>
</tr>
</tbody>
</table>