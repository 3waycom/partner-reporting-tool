<style>
img {max-width:100%}
</style>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" style="text-align: center; color: #090; font-size: 12px;">
  <tr>
    <th scope="col" style="font-size: 10px"><h1><em>3WC SMS subscription service furnishes rich information on healthy living, lifestyle, love, relationship tips, beauty care, business building, movies antertainments and lots more. You can subscribe to recieve wonderful tips delivered to your phones every day. You can also request specific kinds of services you'll like to recieve.
    <p>Click on a service below to get subscribed:</p></em></h1>
    <p>&nbsp;</p></th>
  </tr>
  <tr>
    <th scope="col"><p><a href="http://www.3wc4life.net/product/beauty_care.php"><img src="images/fine_care.jpg" width="100%" height="auto"></a></p></th>
  </tr>
  <tr>
    <td><p><a href="http://www.3wc4life.net/product/life_and_sexuality.php"><img src="images/life_and_sexuality.jpg" width="100%" height="auto"></a></p></td>
  </tr>
  <tr>
    <td><a href="http://www.3wc4life.net/product/family_matters.php"><img src="images/family_matters.jpg" width="100%" height="auto"></a></td>
  </tr>
  <tr>
    <td><a href="http://www.3wc4life.net/product/breast_cancer.php"><img src="images/breast_cancer.jpg" width="100%" height="auto"></a></td>
  </tr>
  <tr>
    <td><p><a href="http://www.3wc4life.net/product/build_your_business.php"><img src="images/buildyourbusiness.jpg" width="100%" height="auto"></a></p></td>
  </tr>
  <tr>
    <td><p>&nbsp;</p></td>
  </tr>
</table>
</body>
</html>