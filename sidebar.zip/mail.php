<?php
(isset($_POST["search"])){
	
	

$to = "somebody@example.com";
$subject = "My subject";
$txt = "Hello world!";
$headers = "From: webmaster@example.com" . "\r\n" .
"CC: somebodyelse@example.com";

mail($to,$subject,$txt,$headers);

}
?>

<body>
<form action="dps.php" method="post" name="mns"  onsubmit="return(validate());">
<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0" style="text-align: left">
  <tr>
    <th colspan="3" align="center" scope="col"><h3>Add New Partner Here</h3></th>
  </tr>
  <tr>
    <td width="33%" valign="bottom">
    <label>
    Signup Date:<br>
<input type="date" placeholder="Sign up Date" name="date" value="" />
    </label></td>
    <td width="33%" valign="bottom">
    <label>
    Full Name:
      <input type="text" placeholder="Full Name" name="partner_name" value="" />
    </label>
    </td>
    <td width="34%" valign="bottom">
        <label>
        Biz/Artiste Name:
      <input type="text" placeholder="Biz/Artiste Name" name="artiste_name" value="" />
    </label>
    </td>
  </tr>
  <tr>
    <td>
    <label>
    Phone Number:
      <input type="text" placeholder="Phone Number" name="phone_number" value="" />
    </label>
    </td>
    <td>
    <label>
    Email Address:
      <input type="email" placeholder="Email Address" name="email_address" value="" />
    </label>
    </td>
    <td>
    <label>
    Address:
      <input type="text" placeholder="Address" name="address" value="" />
    </label>
    </td>
  </tr>
  <tr>
    <td>
    <label>
    Bank Name:
      <input type="text" placeholder="Bank Name" name="bank_name" value="" />
    </label>
    </td>
    <td>
    <label>
    Account Name:
      <input type="text" placeholder="A/C Name" name="account_name" value="" />
    </label>
    </td>
    <td>
    <label>
    Account Number:
      <input type="text" placeholder="A/C Number" name="account_number" value="" />
    </label>
    </td>
  </tr>
  <tr>
    <td>
    <label>
    Broker Bank:
      <input type="text" placeholder="Broker Bank" name="broker_bank" value="" />
    </label>
    </td>
    <td>
    <label>
    Broker A/c Name:
      <input type="text" placeholder="Broker A/c Name" name="broker_account_name" value="" />
    </label>
    </td>
    <td>
    <label>
    Broker A/c No:
      <input type="text" placeholder="Broker A/C No:" name="broker_account_number" value="" />
    </label>
    </td>
  </tr>
  <tr>
    <td>
    <label>
    Rev Share:
      <input type="text" placeholder="Rev Share" name="rev_share" value="" />
    </label>
    </td>
    <td>
    <label>
    Broker Rev Share:
      <input type="text" placeholder="Broker Share" name="broker_share" value="" />
    </label>
    </td>
    <td>
    <label> ID Card Type:
      <select name="card_type">
        <option>Click to Select:</option>
        <option value="National ID Card">National ID Card</option>
        <option value="Drivers Liscense">Drivers Liscense</option>
        <option value="Voters Card">Voters Card</option>
        <option value="PVC">PVC</option>
        <option value="International Passport">International Passport</option>
      </select>
    </label>
    </td>
  </tr>
  <tr>
    <td>
    <label> Content Cover:
      <select name="content_cover">
        <option>Click to Select:</option>
        <option value="SWORN AFFIDAVIT">Sworn Affidavit</option>
        <option value="NCC">NCC</option>
        <option value="COSON">COSON</option>
      </select>
    </label>
    </td>
    <td>
    <label> Service Type:
      <select name="service_type">
        <option>Click to Select:</option>
        <option value="USSD">USSD</option>
        <option value="CRBT">CRBT</option>
        <option value="IVR">IVR</option>
        <option value="SHORTCODE">SHORTCODE</option>
        <option value="MUSIC PLUS">MUSIC PLUS</option>
        <option value="SEITI">SEITI</option>
      </select>
    </label>
    </td>
    <td>
    <label>
    Expiry Date:
      <input type="date" placeholder="Expiry Date" name="expiry_date" value="" />
    </label>
    </td>
  </tr>
  <tr>
    <td>
    <label>
    Comment:
      <input type="text" placeholder="Comment" name="comment" value="" />
    </label>
    </td>
    <td>
    <label>
    3wc Staff:
      <input type="text" placeholder="3wc Staff" name="staff" value="" />
    </label>
    </td>
    <td>
    <label> Priority Type:
      <select name="priority">
        <option>Click to Select:</option>
        <option value="High">High</option>
        <option value="Low">Low</option>
        <option value="Medium">Medium</option>
      </select>
    </label>
    </td>
  </tr>
  <tr>
    <td>
    <div class="features">
	<a href="wlc.php" style="float:left;"><strong>Go Back</strong></a>
	</div>
    </td>
    <td><input type="submit" name="submit1" value="Submit"></td>
    <td>
    <div class="features">
	<a href="update.php"><strong>Next Page</strong></a>
	</div>
    </td>
  </tr>
  <tr>
    <td colspan="3" align="center">3wc (c) 2016</td>
  </tr>
</table>
</form>