<!doctype html>
<html>
<head>
<link href='https://fonts.googleapis.com/css?family=Inconsolata|Dosis' rel='stylesheet' type='text/css'>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>3way Communications Ltd | Home, SMS, CRBT, Subscription, Phones, applications, Softwares, mtn, glo, etisalat, airtel, mobile, mns, huawei, nigeria, 3wc, 3way, communications, network, tele communications</title>
<style>

@media only screen and (max-width: 810px) {
	.col {  margin: 1% 0 1% 0%; }
.ourtable { width: 100%; clear:both;}
}

</style>
</head>

<body style="font-family: 'Dosis', sans-serif;">
<table width="80%" border="0" cellspacing="0" cellpadding="0" align="center" class="ourtable">
  <tr>
    <th scope="col"><?php include 'header.php'?></th>
  </tr>
  <tr>
    <td><?php include 'slider.php'?></td>
  </tr>
  <tr>
    <td><?php include 'content.php'?></td>
  </tr>
  <tr>
    <td><?php include 'footer.php'?></td>
  </tr>
</table>

</body>
</html>
