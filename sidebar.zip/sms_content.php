<style>
img {max-width:100%}
</style>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" style="text-align: center; color: #0F0;">
  <tr>
    <th scope="col"><h1><em>Thanks for joining us!</em></h1>
      <h1><em>Click the images below for more exciting services. Have fun!</em></h1>
    <p>&nbsp;</p></th>
  </tr>
  <tr>
    <th scope="col"><p><a href="http://3wc4life.net/product/business_idea.php"><img src="images/banner_mobile.jpg" width="100%" height="auto" /></a></p>
    <p>&nbsp;</p></th>
  </tr>
  <tr>
    <td><p><a href="http://3wc4life.net/product/beauty_care.php"><img src="images/beauty.jpg" width="100%" height="auto" /></a></p>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td><p><a href="http://3wc4life.net/product/breast_cancer.php"><img src="images/breast.jpg" width="100%" height="auto" /></a></p>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td><p><a href="http://3wc4life.net/product/investment_one.php"><img src="images/byb_banner.jpg" width="100%" height="auto" /></a></p>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td><p>&nbsp;</p>
      <p><a href="http://3wc4life.net/product/fertility_tips.php"><img src="images/fertility.jpg" width="100%" height="auto" /></a></p>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td><p><a href="http://3wc4life.net/product/investment_one.php"><img src="images/INVESTMENT_banner.jpg" width="100%" height="auto" /></a></p>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td><p><a href="http://3wc4life.net/product/life_and_sexuality.php"><img src="images/LIFE AND SEXUALITY_banner.jpg" width="100%" height="auto" /></a></p>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td><p><a href="http://3wc4life.net/product/mobile_dictionary.php"><img src="images/mobile.jpg" width="100%" height="auto" /></a></p>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td><p><a href="http://3wc4life.net/product/movies_box.php"><img src="images/MOVEIS_mobile_banner.jpg" width="100%" height="auto" /></a></p>
    <p>&nbsp;</p></td>
  </tr>
    <tr>
    <td><p><a href="http://3wc4life.net/product/quit_drinking.php"><img src="images/quit_banner.jpg" width="100%" height="auto" /></a></p>
    <p>&nbsp;</p></td>
  </tr>
    <tr>
    <td><p><a href="http://3wc4life.net/product/studying_tips.php"><img src="images/study.jpg" width="100%" height="auto" /></a></p>
    <p>&nbsp;</p></td>
  </tr>
    <tr>
    <td><p><a href="http://3wc4life.net/product/words_of_wisdom.php"><img src="images/word_mobile.jpg" width="100%" height="auto" /></a></p>
    <p>&nbsp;</p></td>
  </tr>
</table>
</body>
</html>