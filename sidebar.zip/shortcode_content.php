<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/service-contents.css">
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div><img src="images/shortcode-banna.jpg" width="100%" height="auto" alt="callertunes"></div>
<div class="section group">
	<div class="col main-article" style="border: solid 1px #c3c3c3; padding:1%">
		<h1>SMS Shortcodes</h1>

<p>Short codes are 4 to 5 digit numbers that are certified for and provisioned on all participating mobile operators. 3WC offers a wide range of SMS services to keep you informed, entertained, and engaged. It can be purchased by making a phone call, sending a text message, or requesting them via the internet or data connection from your mobile phone. The SMS services range from directory assistance services to lifestyle tips to news snippets to inspirational quotes and verses. We continue to expand our range of SMS services daily – sourcing our content from our strategic partners across the world. SMS is one of today’s most popular payment channels. Users can buy ringtones; videos, games pay for WEB site access, participate in a contest, vote for their favorite candidate, participate in TV/Radio programs, and participate in auctions and so on.</p>


<h2>Shortcode Types</h2>


<h3>SMS Subscription:</h3>
<p>SMS Subscription are SMS 160 character delivery messages that subscribers pay a subscription fee through his/her mobile phone to have access to the product/service for a specific period.</p>

<h3>Quiz:</h3>
<p>To nominate candidates for televisions shows. Such as; Voting, Quiz, request programs on TV, Radios and Online where users can contribute their part to a particular TV/Radio program for their favorite contestant. Their entries can either be billed or free.</p>

<h3>Multimedia</h3>
<p>Multimedia: Short codes enables download of multimedia contents such as Full-tracks, ringtones, wallpapers and videos. Subscribers send a keyword to a shortcode and they get a reply message containing a link which they are being advised to click on in order to download the content requested for.</p>

<h3>IVR</h3>
<p>Interactive voice response (IVR) is a technology that allows a computer to interact with humans through the use of voice and DTMF tones input via keypad. It allows a user to dial a dedicated number and be given instructions in the form of voice prompts.</p>
	</div>
	<div class="col main-sidebar"  style="border: solid 1px #c3c3c3;">
	<?php include 'sidebar.php'?>
</div>
</div>
  </div>
  </div>
  </body>